nombre = input("¿cuál es tu nombre? ")
print(f"¡Hola {nombre}!")