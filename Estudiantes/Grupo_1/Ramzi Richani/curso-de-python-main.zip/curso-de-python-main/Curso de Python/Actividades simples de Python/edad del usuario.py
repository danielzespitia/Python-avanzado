edad = int(input("¿Cuántos años tienes? "))
print(f"tengo {edad} años")