comida = "sandwich de pollo frito con aguacate hecho por mamá"
print(comida)