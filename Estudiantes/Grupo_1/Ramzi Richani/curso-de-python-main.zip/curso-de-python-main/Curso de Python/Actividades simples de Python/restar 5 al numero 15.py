resta = 15 - 5
print(resta)