numero1 = 10
numero2 = 20
suma = numero1 + numero2
print(f"{numero1} + {numero2} = {suma}")