mascota = "Vilchez"
print(f"si tuviese una mascota, sería un perro husky llamado {mascota}")