numero1 = 3
numero2 = 4
resultado = numero1 * numero2
print(f"{numero1} multiplicado por {numero2} es {resultado}")