letra = "Immortal temptation Takes over my mind, condemned; Falling weak on my knees Summon the strength of mayhem."
print(letra)