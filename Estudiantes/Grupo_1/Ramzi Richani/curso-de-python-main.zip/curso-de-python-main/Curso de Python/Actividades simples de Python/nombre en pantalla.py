nombre = "Ramzi"
print(nombre)