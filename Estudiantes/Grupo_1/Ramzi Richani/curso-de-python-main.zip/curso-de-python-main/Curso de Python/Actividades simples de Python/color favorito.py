color = input("¿Cuál es tu color favorito? ")
print(f"¡Qué buen gusto! El {color} es genial.")